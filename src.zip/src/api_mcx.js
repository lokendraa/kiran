import axios from 'axios';


export default axios.create({
    baseURL: 'https://fwp.jjw.mybluehostin.me/test123/mcx.php',
    
   
  });
  

  